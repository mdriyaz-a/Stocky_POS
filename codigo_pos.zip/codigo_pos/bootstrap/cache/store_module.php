<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Store\\Providers\\StoreServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Store\\Providers\\StoreServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);